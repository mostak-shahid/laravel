<?php

/*
|--------------------------------------------------------------------------
|This is Project Route
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/* Authontication */
Route::get('/', function () {
    return view('welcome');
});

Route::get('/admin', 'LoginController@index');
Route::post('/submit/login', 'LoginController@submitlogin');

//forget password
Route::get('/forget-password','forgetpasswordController@verifyemail');
Route::post('/submit/verify-email','forgetpasswordController@forgetpassword');
//reset forget Password
Route::get('/admin/w4t{id}j6/reset-password','forgetpasswordController@mailtoresetindex');
Route::post('/submit/email/reset/password','forgetpasswordController@mailtoresetpassword');


Route::group(['prefix' => 'admin'], function () {
    Route::group(['middleware' => 'admin'], function () {
        //dashboard
        Route::get('/dashboard', 'dashboardController@dashboard');
        Route::get('/settings', 'SettingController@setingindex');
        Route::post('basic-setting-add', 'SettingController@basicsettings');
        Route::post('contact-info-add', 'SettingController@contactinfo');
        Route::post('email-info-add', 'SettingController@emailinfo');


    });
});

//Account Setting
//Route::get('/admin/account-setting', 'settingController@accountsetting')->middleware('admin');
//Route::post('/admin/reset/password', 'settingController@updatesetting')->middleware('admin');
////Profile picture upload
//Route::post('/admin/upload/profile-picture', 'settingController@uploadprofilesetting')->middleware('admin');


