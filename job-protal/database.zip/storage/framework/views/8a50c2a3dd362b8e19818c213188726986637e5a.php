<section class="content-header">
    <h1>
        <?php echo $__env->yieldContent('breadcrumb-one'); ?>
        <small><?php echo $__env->yieldContent('breadcrumb-two'); ?></small>
    </h1>
    <?php if(session('success')): ?>
        <div class="row">
        <div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 alert-set-extra" >
            <div class="alert alert-success alert-extra">
                <img src="<?php echo e(asset('image/check.png')); ?>"> <strong>SUCCESS </strong> - <?php echo e(session('success')); ?>.
            </div>
        </div>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="row">
        <div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 alert-set-extra" >
            <div class="alert alert-danger alert-extra" >
                <i class="fa fa-exclamation-triangle "></i> <strong>ERROR ! </strong> - <?php echo e(session('error')); ?>.
            </div>
        </div>
        </div>
    <?php endif; ?>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li class="active"><?php echo $__env->yieldContent('breadcrumb-three'); ?></li>
    </ol>
</section>