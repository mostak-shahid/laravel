<?php $__env->startSection('page_title','Log-In'); ?>
<?php echo $__env->make('admin.layout.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition login-page">
<div class="login-box">
    <!-- /.login-logo -->
    <div class="login-box-body">
        <a class="logo-area" href="<?php echo e(url('/login')); ?>">
            <img class="normal-logo" src="<?php echo e(asset('image/logo-1.png')); ?>">
            <img class="gif-image" src="<?php echo e(asset('image/logo-2.gif')); ?>">
        </a>
          <!----Error message--->
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade in">
                <p class="close" data-dismiss="alert" aria-label="close">&times;</p>
                <strong><i class="fa fa-exclamation-triangle"> </i> ERROR !</strong> <?php echo e(session('error')); ?>.
            </div>
        <?php endif; ?>
         <!----Error message--->

        <p class="login-box-msg box-msg-extra">Sign in to start your session</p>

        <form action="<?php echo e(url('/submit/login')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group has-feedback">
                <input type="email" name="email" class="form-control" placeholder="Email" required>
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <div class="row">
                <!-- /.col -->
                <div class="col-xs-4 pull-right">
                    <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
                </div>
                <!-- /.col -->
            </div>
        </form>

        <a href="<?php echo e(url('/forget-password')); ?>" class="forget-extra">I forgot my password</a><br>

    </div>
    <!-- /.login-box-body -->
</div>
<div class="pull-middle footer-extra"  style="text-align: center">
    <p class="page-footer-extra">© Copyright 2012 - UniGas - All Rights Reserved. Powered by :<a target="_blank" href="http://wanitltd.com/"> WAN IT Ltd.</a></p>
</div>

<!-- /.login-box -->

<!-- jQuery 2.2.3 -->
<script src="<?php echo e(asset('adminasset/plugins/jQuery/jquery-2.2.3.min.js')); ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo e(asset('adminasset/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!-- iCheck -->
<script src="<?php echo e(asset('adminasset/plugins/iCheck/icheck.min.js')); ?>"></script>
<script>
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%' // optional
        });
    });
</script>
</body>
</html>
