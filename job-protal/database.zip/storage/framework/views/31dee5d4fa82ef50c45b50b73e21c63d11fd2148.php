<!-- Core Scripts - Include with every page -->
<script src="<?php echo e(asset('adminasset/js/jquery-1.10.2.js')); ?>"></script>
<?php echo $__env->make('admin.ajax.othersettingajax', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script src="<?php echo e(asset('adminasset/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminasset/js/plugins/metisMenu/jquery.metisMenu.js')); ?>"></script>

<!-- Page-Level Plugin Scripts - Dashboard -->
<script src="<?php echo e(asset('adminasset/js/plugins/morris/raphael-2.1.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminasset/js/plugins/morris/morris.js')); ?>"></script>

<!-- SB Admin Scripts - Include with every page -->
<script src="<?php echo e(asset('adminasset/js/sb-admin.js')); ?>"></script>

<!-- Page-Level Demo Scripts - Dashboard - Use for reference -->
<script src="<?php echo e(asset('adminasset/js/demo/dashboard-demo.js')); ?>"></script>



</body>

</html>
