<?php $__env->startSection('page_title','Reset Password'); ?>
<?php echo $__env->make('admin.layout.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition login-page">
<div class="container">
    <div class="col-md-4 col-md-offset-4">
        <div class="login-box">
    <!-- /.login-logo -->
    <div class="login-box-body">
        <a class="logo-area" href="<?php echo e(url('/login')); ?>">
            <?php if(logo()): ?>
                <img src="<?php echo e(asset(logo())); ?>">
            <?php else: ?>
                <h3>Reset Login</h3>
            <?php endif; ?>
        </a>
        <!----Error message--->
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade in">
                <p class="close" data-dismiss="alert" aria-label="close">&times;</p>
                <strong><i class="fa fa-exclamation-triangle"> </i> ERROR !</strong> <?php echo e(session('error')); ?>.
            </div>
         <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade in">
                <p class="close" data-dismiss="alert" aria-label="close">&times;</p>
                <strong><i class="fa fa-check"> </i> SUCCESS !</strong> <?php echo e(session('success')); ?>.
            </div>
         <?php endif; ?>
    <!----Error message--->

        <p class="login-box-msg box-msg-extra">Reset your Admin Panel password . .</p>

        <form action="<?php echo e(url('/submit/email/reset/password')); ?>" method="post">
            <?php echo e(csrf_field()); ?>


            <input type="hidden" name="id" value="<?php echo e($user->id); ?>" required>

            <div class="form-group has-feedback">
                <div class="input-group ">
                    <input type="password" name="password" id="password"  class="form-control border-radius" placeholder="New Password" required>
                    <span class="input-group-addon border-radius"><i class="fa fa-key"></i> </span>
                </div>
            </div>
            <p id="message" style="font-size: 11px"></p>
            <div class="form-group has-feedback">
                <div class="input-group ">
                    <input type="password" name="conformpassword" id="confirm_password" class="form-control border-radius" placeholder="Conform Password" required>
                    <span class="input-group-addon border-radius"><i class="fa fa-key"></i> </span>
                </div>
            </div>
            <div class="row">
                <!-- /.col -->
                <div class="col-xs-4 pull-right">
                    <button type="submit" class="btn btn-primary btn-block btn-flat border-radius"><i class="fa fa-repeat"> </i> Reset</button>
                </div>
                <div class="col-xs-6 pull-left">
                    <a  href="<?php echo e(url('/admin')); ?>" class="btn btn-default btn-block btn-flat border-radius"><i class="fa fa-reply"> </i> Back to Login</a>
                </div>
                <!-- /.col -->
            </div>
        </form>

    </div>
    <!-- /.login-box-body -->
</div>
    </div>
</div>
<?php echo $__env->make('admin.layout.include.login_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /.login-box -->
<!--password conform password matching script----->

<?php echo $__env->make('admin.layout.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $('#password, #confirm_password').on('keyup', function () {
        if ($('#password').val() == $('#confirm_password').val()) {
            $('#message').html('<i class="fa fa-check"> </i> Password match').css('color', 'green');
        } else
            $('#message').html('<i class="fa fa-exclamation-triangle"> </i> Password Not Matching').css('color', 'red');
    });
</script>



