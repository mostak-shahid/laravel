<div class="pull-middle login-footer"  style="text-align: center">
    <p class="page-footer-extra"><a target="_blank" href="<?php echo e(footer_copylink()); ?>"> <?php echo e(footer_copyright()); ?></a></p>
</div>