<?php $__env->startSection('page_title','Verification Conformation'); ?>
<?php echo $__env->make('admin.layout.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition login-page">
<div class="container">
    <div class="col-md-4 col-md-offset-4">
        <div class="login-box" style="margin: 5% auto;">
    <!-- /.login-logo -->
    <div class="login-box-body">
        <a class="logo-area" href="<?php echo e(url('/login')); ?>">
            <?php if(logo()): ?>
                <img src="<?php echo e(asset(logo())); ?>">
            <?php else: ?>
                <h3>Login</h3>
            <?php endif; ?>
        </a>

        <img src="<?php echo e(asset('image/email.png')); ?>" class="conform-email-extra">
        <p class="login-box-msg box-msg-extra">
            Password Reset mail send to your email Account.Please check your email Account
            and Reset your "Admin Panel" login password . . .</p>
        <div class="text-right " style="padding: 5px">
            <a  href="<?php echo e(url('/admin')); ?>" class="btn btn-default  btn-flat border-radius"> <i class="fa fa-reply"></i> Back to login </a>
        </div>


    </div>
    <!-- /.login-box-body -->
</div>
    </div>
</div>
<?php echo $__env->make('admin.layout.include.login_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- /.login-box -->

<?php echo $__env->make('admin.layout.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
