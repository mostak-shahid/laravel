<?php $__env->startSection('page_title','Log-In'); ?>
<?php echo $__env->make('admin.layout.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition login-page">
<div class="container">
    <div class="col-md-4 col-md-offset-4">
    <!-- /.login-logo -->
    <div class="login-box-body">
        <a class="logo-area" href="<?php echo e(url('/login')); ?>">
            <?php if(logo()): ?>
            <img src="<?php echo e(asset(logo())); ?>">
                <?php else: ?>
                <h3>Login</h3>
            <?php endif; ?>
        </a>
          <!----Error message--->
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade in">
                <p class="close" data-dismiss="alert" aria-label="close">&times;</p>
                <strong><i class="fa fa-exclamation-triangle"> </i> ERROR !</strong> <?php echo e(session('error')); ?>.
            </div>
        <?php endif; ?>
         <!----Error message--->

        <p class="login-box-msg">Sign in to start your session . . </p>

        <form action="<?php echo e(url('/submit/login')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group has-feedback">
                <div class="input-group">
                    <input type="email" name="email" class="form-control border-radius" placeholder="Email Address . ." required>
                    <span class="input-group-addon border-radius"><i class="fa fa-envelope"></i> </span>
                </div>
            </div>
            <div class="form-group has-feedback">
                <div class="input-group">
                    <input type="password" name="password" class="form-control border-radius" placeholder="Password . ." required>
                    <span class="input-group-addon border-radius"><i class="fa fa-key"></i> </span>
                </div>
            </div>
            <div class="row">
                <!-- /.col -->
                <div class="col-xs-4 pull-right">
                    <button type="submit" class="btn btn-primary btn-block border-radius "><i class="fa fa-sign-in"></i> Sign In</button>
                </div>
                <!-- /.col -->
            </div>
        </form>

        <a href="<?php echo e(url('/forget-password')); ?>" class="forget-extra"><i class="fa fa-reply"></i> Forgot Your Password ? </a><br>

    </div>
    <!-- /.login-box-body -->
    </div>
</div>
<?php echo $__env->make('admin.layout.include.login_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- /.login-box -->

<?php echo $__env->make('admin.layout.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
