<!DOCTYPE html>
<html>

<?php echo $__env->make('admin.layout.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<div id="wrapper">

    <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0;background: #4b9663e6;">

        <!-- /.navbar-header -->
          <?php echo $__env->make('admin.layout.include.navber', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- /.navbar-end -->
        <!-- /.navbar-static-side ber -->
          <?php echo $__env->make('admin.layout.include.sideber', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- /.navbar-static-side end -->
    </nav>

    <div id="page-wrapper">
        <div class="row">
            <!-- /.breadcrumb -->
            <?php echo $__env->make('admin.layout.include.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /.breadcrumb end -->
        </div>
        <!-- /.row -->
        <div class="row">

            <?php echo $__env->yieldContent('main_content'); ?>

        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<?php echo $__env->make('admin.layout.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Modal upload profile pic -->

    
        
            
            
                
                    



            
            
        
    
