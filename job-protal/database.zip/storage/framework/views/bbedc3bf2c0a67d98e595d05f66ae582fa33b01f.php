    <div class="col-md-12">
        <div class="btn-group btn-breadcrumb breadcrumb-negro">
            <a href="#" class="btn btn-default"><i class="fa fa-home fa-fw"></i></a>
            <a href="<?php echo e(url('admin/dashboard')); ?>" class="btn btn-info  btn-md">Dashboard</a>
            <a href="#" class="btn btn-info  btn-md"><?php echo $__env->yieldContent('breadcrumbs1'); ?></a>
        </div>
    </div>


