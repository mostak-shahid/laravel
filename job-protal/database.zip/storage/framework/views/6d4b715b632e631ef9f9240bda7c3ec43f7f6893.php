<?php $__env->startSection('page_title','Dashboard'); ?>

<?php $__env->startSection('siderber-accountsetting','active'); ?>
<?php $__env->startSection('siderber-accountsetting','active'); ?>
<?php $__env->startSection('breadcrumb-one','Dashboard'); ?>
<?php $__env->startSection('breadcrumb-two','Account Setting'); ?>
<?php $__env->startSection('breadcrumb-three','Setting'); ?>
<?php $__env->startSection('maincontent'); ?>
    <div class="col-lg-6">
        <div class="row">
            <!-- Table with togglable columns -->
            <div class="panel panel-flat panel-setting-extra">
                <div class="panel-heading panel-default">
                    <h5 class="panel-title"><i class="fa fa-cog"> </i> Reset Account Setting
                    </h5>
                </div>

                <div class="panel-body">
                    <div class="panel-body">
                        <form action="<?php echo e(url('/admin/reset/password')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php if(Sentinel::check()): ?>
                                <div class="form-group">
                                    <label class="control-label">User Name</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-user"></i> </span>
                                        <input type="text" class="form-control" name="name" value="<?php echo e(Sentinel::getuser()->first_name); ?>"  placeholder="User Name..">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Email Address</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-envelope-o"></i> </span>
                                        <input type="email" class="form-control" name="email" value="<?php echo e(Sentinel::getuser()->email); ?>"  placeholder="Enter Email..">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Enter Old Password</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-key"></i> </span>
                                        <input type="password" class="form-control" name="old_password" placeholder="Enter Old Password">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Enter New Password</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-key"></i> </span>
                                        <input type="password" class="form-control" name="password" placeholder="Enter Password">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Enter Conform Password</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-key"></i> </span>
                                        <input type="password" class="form-control" name="password_confirmation" placeholder="Conform Password">
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="pull-right">
                                <button type="submit" class="btn btn-default"><i class="fa  fa-undo"> </i> Reset</button>
                            </div>

                        </form>

                    </div>
                </div>

            </div>
            <!-- /table with togglable columns -->
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>