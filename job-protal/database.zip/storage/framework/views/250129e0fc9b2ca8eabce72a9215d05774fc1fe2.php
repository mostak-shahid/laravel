<?php if(session('success')): ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 alert-set-extra" >
            <div class="alert alert-success alert-extra">
                 <i class="fa fa-check"></i> <strong>SUCCESS </strong> - <?php echo e(session('success')); ?>.
            </div>
        </div>
    </div>
<?php endif; ?>

<!-------Alert For Validation-------->

<?php if($errors->has('logo')): ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 alert-set-extra" >
            <div class="alert alert-danger alert-extra" >
                <i class="fa fa-exclamation-triangle "></i> <strong>ERROR ! </strong> - <?php echo $errors->first('logo'); ?>.
            </div>
        </div>
    </div>
<?php endif; ?>
<?php if($errors->has('sitename')): ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 alert-set-extra" >
            <div class="alert alert-danger alert-extra" >
                <i class="fa fa-exclamation-triangle "></i> <strong>ERROR ! </strong> - <?php echo $errors->first('sitename'); ?>.
            </div>
        </div>
    </div>
<?php endif; ?>