<?php $__env->startSection('page_title','Verification Conformation'); ?>
<?php echo $__env->make('admin.layout.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition login-page">
<div class="login-box" style="margin: 5% auto;">
    <!-- /.login-logo -->
    <div class="login-box-body">
        <a class="logo-area" href="<?php echo e(url('/login')); ?>">
            <img class="normal-logo" src="<?php echo e(asset('image/logo-1.png')); ?>">
            <img class="gif-image" src="<?php echo e(asset('image/logo-2.gif')); ?>">
        </a>

        <img src="<?php echo e(asset('image/email.png')); ?>" class="conform-email-extra">
        <p class="login-box-msg box-msg-extra">
            Password Reset mail send to your email Account.Please check your email Account
            and Reset your "Admin Panel" login password . . .</p>
        <div class="text-right " style="padding: 5px">
            <a  href="<?php echo e(url('/login')); ?>" class="btn btn-default  btn-flat"> <i class="fa fa-reply"></i> Back to login </a>
        </div>


    </div>
    <!-- /.login-box-body -->
</div>
<div class="pull-middle footer-extra"  style="text-align: center">
    <p class="page-footer-extra">© Copyright 2012 - UniGas - All Rights Reserved. Powered by :<a target="_blank" href="http://wanitltd.com/"> WAN IT Ltd.</a></p>
</div>

<!-- /.login-box -->

<!-- jQuery 2.2.3 -->
<script src="<?php echo e(asset('adminasset/plugins/jQuery/jquery-2.2.3.min.js')); ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo e(asset('adminasset/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!-- iCheck -->
<script src="<?php echo e(asset('adminasset/plugins/iCheck/icheck.min.js')); ?>"></script>
<script>
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%' // optional
        });
    });
</script>
</body>
</html>
