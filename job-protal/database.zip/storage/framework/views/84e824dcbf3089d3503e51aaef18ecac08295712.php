
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo e(site_name()); ?> - Admin Panel</title>
    <link rel="icon" href="<?php echo e(asset(favicon())); ?>">
    <!-------Google fonts cdn------->
    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Aldrich' rel='stylesheet'>
    <!-- Core CSS - Include with every page -->
    <link href="<?php echo e(asset('adminasset/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminasset/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">

    <!-- Page-Level Plugin CSS - Dashboard -->
    <link href="<?php echo e(asset('adminasset/css/plugins/morris/morris-0.4.3.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminasset/css/plugins/timeline/timeline.css')); ?>" rel="stylesheet">

    <!-- SB Admin CSS - Include with every page -->
    <link href="<?php echo e(asset('adminasset/css/sb-admin.css')); ?>" rel="stylesheet">
    <!-------custom css------->
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">


    <!----Script for alert Close timely---->
    <script>
    window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
    $(this).remove();
    });
    }, 4000);
    </script>

</head>