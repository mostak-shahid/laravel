@section('page_title','Reset Password')
@include('admin.layout.include.header')
<body class="hold-transition login-page">
<div class="container">
    <div class="col-md-4 col-md-offset-4">
        <div class="login-box">
    <!-- /.login-logo -->
    <div class="login-box-body">
        <a class="logo-area" href="{{url('/login')}}">
            @if(logo())
                <img src="{{asset(logo())}}">
            @else
                <h3>Reset Login</h3>
            @endif
        </a>
        <!----Error message--->
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade in">
                <p class="close" data-dismiss="alert" aria-label="close">&times;</p>
                <strong><i class="fa fa-exclamation-triangle"> </i> ERROR !</strong> {{session('error')}}.
            </div>
         @endif
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade in">
                <p class="close" data-dismiss="alert" aria-label="close">&times;</p>
                <strong><i class="fa fa-check"> </i> SUCCESS !</strong> {{session('success')}}.
            </div>
         @endif
    <!----Error message--->

        <p class="login-box-msg box-msg-extra">Reset your Admin Panel password . .</p>

        <form action="{{url('/submit/email/reset/password')}}" method="post">
            {{csrf_field()}}

            <input type="hidden" name="id" value="{{$user->id}}" required>

            <div class="form-group has-feedback">
                <div class="input-group ">
                    <input type="password" name="password" id="password"  class="form-control border-radius" placeholder="New Password" required>
                    <span class="input-group-addon border-radius"><i class="fa fa-key"></i> </span>
                </div>
            </div>
            <p id="message" style="font-size: 11px"></p>
            <div class="form-group has-feedback">
                <div class="input-group ">
                    <input type="password" name="conformpassword" id="confirm_password" class="form-control border-radius" placeholder="Conform Password" required>
                    <span class="input-group-addon border-radius"><i class="fa fa-key"></i> </span>
                </div>
            </div>
            <div class="row">
                <!-- /.col -->
                <div class="col-xs-4 pull-right">
                    <button type="submit" class="btn btn-primary btn-block btn-flat border-radius"><i class="fa fa-repeat"> </i> Reset</button>
                </div>
                <div class="col-xs-6 pull-left">
                    <a  href="{{url('/admin')}}" class="btn btn-default btn-block btn-flat border-radius"><i class="fa fa-reply"> </i> Back to Login</a>
                </div>
                <!-- /.col -->
            </div>
        </form>

    </div>
    <!-- /.login-box-body -->
</div>
    </div>
</div>
@include('admin.layout.include.login_footer')
<!-- /.login-box -->
<!--password conform password matching script----->

@include('admin.layout.include.script')

<script>
    $('#password, #confirm_password').on('keyup', function () {
        if ($('#password').val() == $('#confirm_password').val()) {
            $('#message').html('<i class="fa fa-check"> </i> Password match').css('color', 'green');
        } else
            $('#message').html('<i class="fa fa-exclamation-triangle"> </i> Password Not Matching').css('color', 'red');
    });
</script>



