@section('page_title','Verification Conformation')
@include('admin.layout.include.header')
<body class="hold-transition login-page">
<div class="container">
    <div class="col-md-4 col-md-offset-4">
        <div class="login-box" style="margin: 5% auto;">
    <!-- /.login-logo -->
    <div class="login-box-body">
        <a class="logo-area" href="{{url('/login')}}">
            @if(logo())
                <img src="{{asset(logo())}}">
            @else
                <h3>Login</h3>
            @endif
        </a>

        <img src="{{asset('image/email.png')}}" class="conform-email-extra">
        <p class="login-box-msg box-msg-extra">
            Password Reset mail send to your email Account.Please check your email Account
            and Reset your "Admin Panel" login password . . .</p>
        <div class="text-right " style="padding: 5px">
            <a  href="{{url('/admin')}}" class="btn btn-default  btn-flat border-radius"> <i class="fa fa-reply"></i> Back to login </a>
        </div>


    </div>
    <!-- /.login-box-body -->
</div>
    </div>
</div>
@include('admin.layout.include.login_footer')

<!-- /.login-box -->

@include('admin.layout.include.script')
