@section('page_title','Log-In')
@include('admin.layout.include.header')
<body class="hold-transition login-page">
<div class="container">
    <div class="col-md-4 col-md-offset-4">
    <!-- /.login-logo -->
    <div class="login-box-body">
        <a class="logo-area" href="{{url('/login')}}">
            @if(logo())
            <img src="{{asset(logo())}}">
                @else
                <h3>Login</h3>
            @endif
        </a>
          <!----Error message--->
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade in">
                <p class="close" data-dismiss="alert" aria-label="close">&times;</p>
                <strong><i class="fa fa-exclamation-triangle"> </i> ERROR !</strong> {{session('error')}}.
            </div>
        @endif
         <!----Error message--->

        <p class="login-box-msg">Sign in to start your session . . </p>

        <form action="{{url('/submit/login')}}" method="post">
            {{csrf_field()}}
            <div class="form-group has-feedback">
                <div class="input-group">
                    <input type="email" name="email" class="form-control border-radius" placeholder="Email Address . ." required>
                    <span class="input-group-addon border-radius"><i class="fa fa-envelope"></i> </span>
                </div>
            </div>
            <div class="form-group has-feedback">
                <div class="input-group">
                    <input type="password" name="password" class="form-control border-radius" placeholder="Password . ." required>
                    <span class="input-group-addon border-radius"><i class="fa fa-key"></i> </span>
                </div>
            </div>
            <div class="row">
                <!-- /.col -->
                <div class="col-xs-4 pull-right">
                    <button type="submit" class="btn btn-primary btn-block border-radius "><i class="fa fa-sign-in"></i> Sign In</button>
                </div>
                <!-- /.col -->
            </div>
        </form>

        <a href="{{url('/forget-password')}}" class="forget-extra"><i class="fa fa-reply"></i> Forgot Your Password ? </a><br>

    </div>
    <!-- /.login-box-body -->
    </div>
</div>
@include('admin.layout.include.login_footer')

<!-- /.login-box -->

@include('admin.layout.include.script')
