<div class="pull-middle login-footer"  style="text-align: center">
    <p class="page-footer-extra"><a target="_blank" href="{{footer_copylink()}}"> {{footer_copyright()}}</a></p>
</div>