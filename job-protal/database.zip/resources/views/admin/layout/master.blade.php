<!DOCTYPE html>
<html>

@include('admin.layout.include.header')

<body>

<div id="wrapper">

    <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0;background: #4b9663e6;">

        <!-- /.navbar-header -->
          @include('admin.layout.include.navber')
        <!-- /.navbar-end -->
        <!-- /.navbar-static-side ber -->
          @include('admin.layout.include.sideber')
        <!-- /.navbar-static-side end -->
    </nav>

    <div id="page-wrapper">
        <div class="row">
            <!-- /.breadcrumb -->
            @include('admin.layout.include.breadcrumb')
            <!-- /.breadcrumb end -->
        </div>
        <!-- /.row -->
        <div class="row">

            @yield('main_content')

        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
@include('admin.layout.include.script')

<!-- Modal upload profile pic -->
{{--<script>--}}
    {{--function readURL(input){--}}
        {{--if(input.files && input.files[0]){--}}
            {{--var reader=new FileReader();--}}
            {{--reader.onload=function (e) {--}}
                {{--$('#blah')--}}
                    {{--.attr('src',e.target.result)--}}
{{--//                    .width(358)--}}
{{--//                    .height(215);--}}

            {{--};--}}
            {{--reader.readAsDataURL(input.files[0]);--}}
        {{--}--}}
    {{--}--}}
{{--</script>--}}