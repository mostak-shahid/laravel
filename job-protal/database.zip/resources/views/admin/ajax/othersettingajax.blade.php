<script type="text/javascript">
    {{--$(document).on('click', '#basicSetting', function(){--}}
        {{--var formData = $("#basic_form_data").serialize();--}}
        {{--$.ajax({--}}
            {{--url: '{!! URL::route("basic-setting-add") !!}',--}}
            {{--cache: false,--}}
            {{--type: "POST",--}}
            {{--data: formData,--}}

            {{--success: function(data) {--}}
{{--//                $.alert({--}}
{{--//                    title: 'SUCCESS !',--}}
{{--//                    content:'Data uploaded Successfully',--}}
{{--//                    type: 'green',--}}
{{--//                    typeAnimated: true--}}
{{--//                });--}}
            {{--},--}}
            {{--error: function (request, status, error) {--}}
                {{--json = $.parseJSON(request.responseText);--}}
                {{--$.each(json.errors, function(key, value){--}}
                    {{--$.alert({--}}
                        {{--title: 'Encountered an error!',--}}
                        {{--content:value,--}}
                        {{--type: 'red',--}}
                        {{--typeAnimated: true,--}}
                    {{--});--}}
                {{--});--}}

            {{--}--}}
        {{--})--}}
    {{--});--}}
</script>