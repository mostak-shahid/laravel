<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BasicSettings extends Model
{
    //
}
