<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adminrPofile extends Model
{
    protected $fillable=[
        'admin_id','image',
    ];
}
