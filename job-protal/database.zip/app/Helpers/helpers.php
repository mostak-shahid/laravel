<?php

function logo($id=null){
    $site_basic=\App\BasicSettings::first();
    $logo=$site_basic->logo;
    return $logo;
}
function site_name($id=null){
    $site_basic=\App\BasicSettings::first();
    $site_name=$site_basic->sitename;
    return $site_name;
}
function favicon($id=null){
    $site_basic=\App\BasicSettings::first();
    $site_favicon=$site_basic->favicon;
    return $site_favicon;
}
function footer_copyright($id=null){
    $footer_basic=\App\BasicSettings::first();
    $site_copyright=$footer_basic->footertext;
    return $site_copyright;
}
function footer_copylink($id=null){
    $footer_link=\App\BasicSettings::first();
    $site_copyright=$footer_link->footerlink;
    return $site_copyright;
}
